const express = require("express");
const router = express.Router();
const { auth } = require("../Helpers/auth");
const {
  postBookingTrip,
  deleteTrip,
  getTrip,
  postTrip,
} = require("../controllers/trip");

router.post("/trip", auth(["admin"]), postTrip);

router.get("/trip", auth(), getTrip);

router.delete("/trip", auth(["admin"]), deleteTrip);

router.post("/trip/booking", auth(), postBookingTrip);

module.exports = router;
